$('document').ready(function(){
    alert('test from Jquery');
});